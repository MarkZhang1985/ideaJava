package java5152.cake;

/**
 * 类名：ChocolateCake
 * 实现接口：Cake
 * 成员方法：重写接口方法show()
 */
public class ChocolateCake implements Cake {
	@Override
	public void show() {
		System.out.println("这是巧克力蛋糕！");
	}
}
