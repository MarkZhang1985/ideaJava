package java5152.cake;

public interface Cake {

	public abstract void show();
}
