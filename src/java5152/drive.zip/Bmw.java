package java5152.drive;

/**
 * 类：宝马车，重写驾驶函数
 */
public class Bmw implements Drive {
	@Override
	public void drive() {
		System.out.println("正在驾驶宝马车...");
	}
}
