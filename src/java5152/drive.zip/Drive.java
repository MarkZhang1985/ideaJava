package java5152.drive;

/**
 * 接口：实现开车行为
 */
public interface Drive {
	public abstract void drive();
}
