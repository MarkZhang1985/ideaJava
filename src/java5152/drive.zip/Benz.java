package java5152.drive;

/**
 * 类：奔驰车，重写驾驶函数
 */
public class Benz implements Drive {
	@Override
	public void drive() {
		System.out.println("正在驾驶奔驰车...");
	}
}
